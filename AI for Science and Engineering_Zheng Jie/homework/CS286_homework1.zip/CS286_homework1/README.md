# CS286 AI for Science and Engineering (Fall 2023)
-------------------------------------------------------

### Homework 1

**Question 1: BreaKHis Challenge** (50 points)
**Question 2: PyTorch Implementation of Generative Adverarial Network (GAN)** (50 points)

#### Notes:

You are required to complete both questions independently. Plagiarism is strictly prohibited. Source code should not be shared with any other student in any form. Please submit your solutions (in a zip file containing two jupyter notebook files) to Blackboard. The zip file should be named in this format: CS286_ID_name_hw1. For example, CS286_2019123321_zhangSan_hw1.zip. **Do not upload the datasets in submission**. For late Policy please refer to the course slides.


#### Deadline of submission
2023/11/26 23:59:59

